# PIU_AI v0.8 — Companion Extras (source project)

এই প্যাকেজটি v0.7 সোর্সের ওপর অতিরিক্ত কিছু ব্যবহারকারী-নিয়ন্ত্রিত সুবিধা যোগ করে।

## এই সংস্করণে যোগ করা হয়েছে
- ফোনের ডায়ালার খোলার বোতাম (ACTION_DIAL; নিজে কল নিশ্চিত করতে হবে)।
- SMS অ্যাপ খোলার বোতাম (মেসেজ নিজে দেখে পাঠাতে হবে)।
- Android Settings খোলার শর্টকাট।
- ঐচ্ছিক দৈনিক রাত ৮টার লোকাল check-in notification; ব্যবহারকারী চালু/বন্ধ করতে পারবেন।
- ফোন রিস্টার্টের পর চালু থাকা reminder পুনরায় schedule করার receiver।
- আগের AI chat, image picker, TTS avatar এবং background listening source রাখা হয়েছে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি Android Studio/Kotlin source, APK নয়। এখানে Gradle/Android SDK দিয়ে compile করা বা vivo Y400 Pro 5G-তে চালানো হয়নি।
- ডায়ালার/মেসেজ শর্টকাট ফোনের সংশ্লিষ্ট অ্যাপ খোলে; নিজে থেকে কল বা SMS করে না।
- check-in notification একটি নির্দিষ্ট স্থানীয় নোটিফিকেশন; AI নিজে থেকে ব্যক্তিগত মেসেজ তৈরি করে পাঠায় না।
- background microphone service একটি user-started foreground service prototype। এটি wake-word engine নয়; Android/Vivo battery policy, Speech Services এবং অনুমতির কারণে বিরতি/বন্ধ হতে পারে। ফোন পুরোপুরি বন্ধ থাকলে শোনা অসম্ভব।
- “কল” এখনও অ্যাপের ভিতরের speech-recognition/TTS কথোপকথন; cellular/video call নয়। avatar mouth motion প্রকৃত lip-sync নয়।
- ফোনের সব কাজ স্বয়ংক্রিয়ভাবে করার অনুমতি নেই; শুধু দৃশ্যমান, ব্যবহারকারী-নিয়ন্ত্রিত শর্টকাট যোগ করা হয়েছে।
- API key সরাসরি Android অ্যাপ থেকে OpenAI-তে পাঠানো হচ্ছে। Android Keystore-এ সংরক্ষণ হলেও rooted/compromised device বা reverse engineering-এর বিরুদ্ধে এটি সম্পূর্ণ সুরক্ষা নয়। বাস্তব ব্যবহারের জন্য server-side proxy দরকার। API key কখনো কারও সঙ্গে শেয়ার করবেন না।
- OpenAI API usage আলাদা বিলযোগ্য হতে পারে।

## Build
Android Studio-তে এই ফোল্ডারটি খুলে Gradle sync করে APK build করতে হবে। Build সফল হওয়া বা কোনো নির্দিষ্ট ফোনে চলার নিশ্চয়তা দেওয়া হচ্ছে না, কারণ এখানে compile/device test করা হয়নি।
