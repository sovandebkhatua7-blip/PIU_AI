plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.piuai.companion"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.piuai.companion"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "0.7.0"
    }
}
