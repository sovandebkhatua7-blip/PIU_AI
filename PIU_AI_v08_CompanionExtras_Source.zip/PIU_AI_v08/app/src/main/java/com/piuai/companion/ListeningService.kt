package com.piuai.companion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** User-started foreground microphone service. It is NOT an always-on wake-word engine. */
class ListeningService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var stopping = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("PIU_AI শুনছে")
                .setContentText("মাইক্রোফোন চালু আছে। বন্ধ করতে PIU_AI খুলুন।")
                .setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("PIU_AI শুনছে").setContentText("মাইক্রোফোন চালু আছে")
                .setOngoing(true).build()
        }
        startForeground(4107, notification)
        startRecognition()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "PIU_AI মাইক্রোফোন", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun startRecognition() {
        if (stopping) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendStatus("এই ফোনে speech recognition পাওয়া যায়নি।")
            stopSelf(); return
        }
        try {
            if (recognizer == null) recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: android.os.Bundle?) { sendStatus("PIU_AI শুনছে…") }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) { if (!stopping) handler.postDelayed({ startRecognition() }, 900) }
                    override fun onResults(results: android.os.Bundle?) {
                        val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val phrase = words?.firstOrNull()?.trim().orEmpty()
                        if (phrase.isNotEmpty()) {
                            sendBroadcast(Intent(ACTION_PHRASE).setPackage(packageName).putExtra(EXTRA_PHRASE, phrase))
                        }
                        if (!stopping) handler.postDelayed({ startRecognition() }, 700)
                    }
                    override fun onPartialResults(partialResults: android.os.Bundle?) {}
                    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                })
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            if (!stopping) handler.postDelayed({ startRecognition() }, 1500)
        }
    }

    private fun sendStatus(message: String) {
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra(EXTRA_PHRASE, message))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopping = true; stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    override fun onDestroy() {
        stopping = true
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy(); recognizer = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL = "piu_mic_channel"
        const val ACTION_PHRASE = "com.piuai.companion.PHRASE"
        const val ACTION_STATUS = "com.piuai.companion.STATUS"
        const val ACTION_STOP = "com.piuai.companion.STOP_LISTENING"
        const val EXTRA_PHRASE = "phrase"
    }
}
