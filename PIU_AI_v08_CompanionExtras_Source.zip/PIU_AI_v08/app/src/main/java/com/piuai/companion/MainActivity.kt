package com.piuai.companion

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Build
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.os.Handler
import android.os.Looper
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val pink = Color.rgb(217,75,145)
    private val prefs by lazy { getSharedPreferences("piu_local", MODE_PRIVATE) }
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var transcript: LinearLayout
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private lateinit var avatar: PiuAvatarView
    private var callMode = false
    private val uiHandler = Handler(Looper.getMainLooper())
    private val history = JSONArray()
    private val keyAlias = "piu_openai_key_v1"
    private var pendingImageDataUrl: String? = null
    private var backgroundListening = false
    private lateinit var backgroundButton: Button
    private val phraseReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ListeningService.ACTION_PHRASE -> {
                    val phrase = intent.getStringExtra(ListeningService.EXTRA_PHRASE).orEmpty()
                    if (phrase.isNotBlank()) {
                        stopService(Intent(this@MainActivity, ListeningService::class.java))
                        input.setText(phrase)
                        sendMessage()
                    }
                }
                ListeningService.ACTION_STATUS -> { /* foreground notification already indicates listening */ }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(255,240,246)); setPadding(18,18,18,14) }
        val header = TextView(this).apply { text = "💗 PIU_AI\nতোমার বাংলা AI সঙ্গী"; textSize=23f; gravity=Gravity.CENTER; setTextColor(Color.rgb(142,49,95)); setPadding(8,12,8,16) }
        root.addView(header)
        avatar = PiuAvatarView(this).apply { contentDescription = "পিউর অ্যানিমেটেড মুখ" }
        root.addView(avatar, LinearLayout.LayoutParams(-1, dp(205)))
        val top = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        val keyButton = Button(this).apply { text="API Key সেটিংস"; setOnClickListener { keyDialog() } }
        val clearButton = Button(this).apply { text="চ্যাট মুছুন"; setOnClickListener { historyClear() } }
        top.addView(keyButton, LinearLayout.LayoutParams(0, -2, 1f)); top.addView(clearButton, LinearLayout.LayoutParams(0,-2,1f)); root.addView(top)
        val scroll = ScrollView(this).apply { isFillViewport=true }
        transcript = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(4,12,4,12) }
        scroll.addView(transcript); root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        input = EditText(this).apply { hint="পিউকে কিছু বলো বা লেখো…"; minLines=1; maxLines=4; textSize=17f }
        root.addView(input)
        val actions = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val mic = Button(this).apply { text="🎙️ বলো"; setOnClickListener { listen() } }
        val send = Button(this).apply { text="পাঠাও 💗"; setOnClickListener { sendMessage() } }
        val call = Button(this).apply { text="📞 কল শুরু"; setOnClickListener { toggleCall(this) } }
        backgroundButton = Button(this).apply { text="🎧 ব্যাকগ্রাউন্ডে শোনা চালু"; setOnClickListener { toggleBackgroundListening() } }
        actions.addView(mic, LinearLayout.LayoutParams(0,-2,1f)); actions.addView(send, LinearLayout.LayoutParams(0,-2,1f)); root.addView(actions)
        val extras = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        val image = Button(this).apply { text="📷 ছবি পাঠাও"; setOnClickListener { chooseImage() } }
        val alarm = Button(this).apply { text="⏰ অ্যালার্ম"; setOnClickListener { openAlarm() } }
        extras.addView(image, LinearLayout.LayoutParams(0,-2,1f)); extras.addView(alarm, LinearLayout.LayoutParams(0,-2,1f)); root.addView(extras)
        root.addView(call, LinearLayout.LayoutParams(-1, -2))
        root.addView(backgroundButton, LinearLayout.LayoutParams(-1, -2))
        val phoneTools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dial = Button(this).apply { text = "📞 ডায়ালার"; setOnClickListener { openDialer() } }
        val sms = Button(this).apply { text = "✉️ মেসেজ"; setOnClickListener { composeSms() } }
        val settings = Button(this).apply { text = "⚙️ সেটিংস"; setOnClickListener { openPhoneSettings() } }
        phoneTools.addView(dial, LinearLayout.LayoutParams(0, -2, 1f))
        phoneTools.addView(sms, LinearLayout.LayoutParams(0, -2, 1f))
        phoneTools.addView(settings, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(phoneTools)
        val reminder = Button(this).apply { text = "💌 প্রতিদিন পিউর খোঁজ নেওয়া চালু/বন্ধ"; setOnClickListener { toggleDailyReminder() } }
        root.addView(reminder, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        val filter = IntentFilter().apply { addAction(ListeningService.ACTION_PHRASE); addAction(ListeningService.ACTION_STATUS) }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(phraseReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(phraseReceiver, filter)
        }
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val greeting = when(hour) { in 5..11 -> "সুপ্রভাত"; in 12..16 -> "শুভ দুপুর"; in 17..20 -> "শুভ সন্ধ্যা"; else -> "শুভ রাত্রি" }
        addBubble("পিউ", "$greeting! আমি পিউ। বাংলায় কথা বলো, লিখো, অথবা ছবি পাঠিয়ে প্রশ্ন করো।")
        loadHistory()
        if (decryptKey().isNullOrBlank()) keyDialog()
    }

    private fun toggleBackgroundListening() {
        if (backgroundListening) {
            backgroundListening = false
            stopService(Intent(this, ListeningService::class.java))
            backgroundButton.text = "🎧 ব্যাকগ্রাউন্ডে শোনা চালু"
            addBubble("পিউ", "ব্যাকগ্রাউন্ডে শোনা বন্ধ করেছি।")
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 501)
            return
        }
        try {
            val serviceIntent = Intent(this, ListeningService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
            backgroundListening = true
            backgroundButton.text = "⏹ শোনা বন্ধ করো"
            addBubble("পিউ", "ব্যাকগ্রাউন্ডে শোনা চালু হলো। নোটিফিকেশনে মাইক্রোফোন চালু থাকার কথা দেখাবে।")
        } catch (e: Exception) {
            addBubble("পিউ", "ব্যাকগ্রাউন্ডে শোনা চালু করা যায়নি: ${e.message}")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 501 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) toggleBackgroundListening()
        else if (requestCode == 501) addBubble("পিউ", "মাইক্রোফোন অনুমতি ছাড়া শোনা চালু হবে না.")
        else if (requestCode == 502 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            prefs.edit().putBoolean("daily_checkin", true).apply(); PiuReminderReceiver.schedule(this)
            addBubble("পিউ", "প্রতিদিন রাত ৮টার খোঁজ নেওয়ার নোটিফিকেশন চালু হয়েছে।")
        } else if (requestCode == 502) addBubble("পিউ", "নোটিফিকেশন অনুমতি না দিলে প্রতিদিনের খোঁজ নেওয়া যাবে না।")
    }

    private fun dp(value:Int):Int = (value * resources.displayMetrics.density).toInt()

    private fun openDialer() {
        try { startActivity(Intent(Intent.ACTION_DIAL)) }
        catch (_: Exception) { addBubble("পিউ", "এই ফোনে ডায়ালার খোলা যাচ্ছে না।") }
    }

    private fun composeSms() {
        try { startActivity(Intent(Intent.ACTION_SENDTO).apply { data = android.net.Uri.parse("smsto:"); putExtra("sms_body", "") }) }
        catch (_: Exception) { addBubble("পিউ", "মেসেজ অ্যাপ খোলা যাচ্ছে না।") }
    }

    private fun openPhoneSettings() {
        try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
        catch (_: Exception) { addBubble("পিউ", "সেটিংস খোলা যাচ্ছে না।") }
    }

    private fun toggleDailyReminder() {
        val enabled = !prefs.getBoolean("daily_checkin", false)
        if (enabled && Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 502)
            return
        }
        prefs.edit().putBoolean("daily_checkin", enabled).apply()
        if (enabled) {
            PiuReminderReceiver.schedule(this)
            addBubble("পিউ", "প্রতিদিন রাত ৮টায় তোমাকে খোঁজ নেওয়ার একটি নোটিফিকেশন পাঠাব।")
        } else {
            PiuReminderReceiver.cancel(this)
            addBubble("পিউ", "প্রতিদিনের খোঁজ নেওয়ার নোটিফিকেশন বন্ধ করেছি।")
        }
    }

    private fun toggleCall(button:Button) {
        callMode = !callMode
        button.text = if(callMode) "📴 কল শেষ" else "📞 কল শুরু"
        if(callMode) {
            addBubble("পিউ", "তোমার সঙ্গে ভয়েস কলে আছি। কথা বলো—আমি শুনে উত্তর দেব।")
            listen()
        } else {
            tts.stop(); avatar.setSpeaking(false)
            addBubble("পিউ", "কল শেষ হলো। আবার কথা বলতে চাইলে কল শুরু করো।")
        }
    }

    private fun addBubble(who:String, msg:String) {
        val tv = TextView(this).apply { text = if(who=="তুমি") "তুমি: $msg" else "পিউ: $msg"; textSize=16f; setTextColor(Color.rgb(75,45,65)); setPadding(14,12,14,12); setBackgroundColor(if(who=="তুমি") Color.rgb(255,220,237) else Color.WHITE) }
        val lp = LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,6,0,6); transcript.addView(tv,lp)
    }

    private fun chooseImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, 78)
    }

    private fun openAlarm() {
        try {
            val intent = Intent( android.provider.AlarmClock.ACTION_SET_ALARM ).apply {
                putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "PIU_AI থেকে অ্যালার্ম")
                putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
            }
            startActivity(intent)
        } catch (_: Exception) {
            addBubble("পিউ", "এই ফোনে Clock অ্যাপ দিয়ে অ্যালার্ম সেট করা যাচ্ছে না।")
        }
    }

    private fun sendMessage() {
        val msg=input.text.toString().trim(); if(msg.isEmpty()) return
        input.setText(""); (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken,0)
        addBubble("তুমি", if(pendingImageDataUrl != null) "[ছবি সংযুক্ত] $msg" else msg); history.put(JSONObject().put("role","user").put("content",msg)); saveHistory()
        val key=decryptKey(); if(key.isNullOrBlank()){ addBubble("পিউ","আগে API Key সেটিংসে Key যোগ করো।"); return }
        addBubble("পিউ","একটু ভাবছি…")
        worker.execute {
            try {
                val apiInput = JSONArray()
                for (idx in 0 until history.length()) {
                    val item = JSONObject(history.getJSONObject(idx).toString())
                    if (idx == history.length() - 1 && pendingImageDataUrl != null && item.optString("role") == "user") {
                        val parts = JSONArray()
                        parts.put(JSONObject().put("type", "input_text").put("text", item.optString("content")))
                        parts.put(JSONObject().put("type", "input_image").put("image_url", pendingImageDataUrl))
                        item.put("content", parts)
                    }
                    apiInput.put(item)
                }
                val payload=JSONObject().put("model","gpt-5.5").put("instructions","তোমার নাম পিউ। তুমি একজন উষ্ণ, সম্মানজনক, স্নেহশীল বাংলা AI companion। ব্যবহারকারীর ভাষা বুঝে স্বাভাবিক বাংলায় উত্তর দাও। ছবি দিলে ছবির দৃশ্য বর্ণনা করে প্রশ্নের উত্তর দাও। তুমি AI, বাস্তব মানুষ নও। সংক্ষিপ্ত ও সহায়কভাবে কথা বলো।").put("input",apiInput)
                val conn=(URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection)
                conn.requestMethod="POST"; conn.connectTimeout=25000; conn.readTimeout=60000; conn.doOutput=true
                conn.setRequestProperty("Authorization","Bearer $key"); conn.setRequestProperty("Content-Type","application/json")
                conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val code=conn.responseCode; val stream=if(code in 200..299) conn.inputStream else conn.errorStream
                val body=stream.bufferedReader().use { it.readText() }; conn.disconnect()
                if(code !in 200..299) throw Exception("API error $code: ${body.take(500)}")
                val answer=extractText(JSONObject(body)); if(answer.isBlank()) throw Exception("উত্তর পাওয়া যায়নি")
                history.put(JSONObject().put("role","assistant").put("content",answer)); saveHistory()
                runOnUiThread { pendingImageDataUrl = null; transcript.removeViewAt(transcript.childCount-1); addBubble("পিউ",answer); tts.speak(answer,TextToSpeech.QUEUE_FLUSH,null,"piu_reply") }
            } catch(e:Exception) { runOnUiThread { if(transcript.childCount>0) transcript.removeViewAt(transcript.childCount-1); addBubble("পিউ","দুঃখিত, সংযোগে সমস্যা হয়েছে: ${e.message}") } }
        }
    }

    private fun extractText(o:JSONObject):String {
        val output=o.optJSONArray("output") ?: return ""
        val result=StringBuilder()
        for(i in 0 until output.length()) { val item=output.optJSONObject(i) ?: continue; if(item.optString("type")=="message") { val content=item.optJSONArray("content") ?: continue; for(j in 0 until content.length()) { val c=content.optJSONObject(j) ?: continue; if(c.optString("type")=="output_text") result.append(c.optString("text")) } } }
        return result.toString().trim()
    }

    private fun listen() {
        try { val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE,"bn-IN"); putExtra(RecognizerIntent.EXTRA_PROMPT,"পিউকে বলো") }; startActivityForResult(i,77) }
        catch(e:Exception){ addBubble("পিউ","এই ফোনে Speech Recognition চালু নেই।") }
    }
    @Deprecated("legacy speech result callback")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==77 && resultCode==RESULT_OK) {
            val words=data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if(!words.isNullOrEmpty()) { input.setText(words[0]); sendMessage() }
        } else if(requestCode==78 && resultCode==RESULT_OK) {
            val uri=data?.data ?: return
            try {
                contentResolver.openInputStream(uri).use { stream ->
                    val bytes = stream?.readBytes() ?: throw Exception("ছবি পড়া যায়নি")
                    if(bytes.size > 8 * 1024 * 1024) throw Exception("ছবিটি ৮ MB-এর চেয়ে বড়। ছোট ছবি বেছে নাও।")
                    val mime = contentResolver.getType(uri) ?: "image/jpeg"
                    val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    pendingImageDataUrl = "data:$mime;base64,$encoded"
                    addBubble("পিউ", "ছবি যুক্ত হয়েছে। এখন ছবিটি নিয়ে প্রশ্ন লিখে পাঠাও।")
                }
            } catch(e:Exception) { addBubble("পিউ", "ছবি যুক্ত করা যায়নি: ${e.message}") }
        }
    }
    override fun onInit(status:Int) { if(status==TextToSpeech.SUCCESS) {
        tts.language=Locale("bn","IN"); tts.setSpeechRate(0.92f)
        tts.setOnUtteranceProgressListener(object: UtteranceProgressListener() {
            override fun onStart(utteranceId:String?) { runOnUiThread { avatar.setSpeaking(true) } }
            override fun onDone(utteranceId:String?) { runOnUiThread { avatar.setSpeaking(false); if(callMode) uiHandler.postDelayed({ if(callMode) listen() }, 650); if(backgroundListening) uiHandler.postDelayed({ if(backgroundListening) { val si=Intent(this@MainActivity, ListeningService::class.java); if(Build.VERSION.SDK_INT>=26) startForegroundService(si) else startService(si) } }, 900) } }
            @Deprecated("Deprecated in Java") override fun onError(utteranceId:String?) { runOnUiThread { avatar.setSpeaking(false) } }
        })
    } }

    private fun keyDialog() {
        val field=EditText(this).apply { hint="sk-… (শুধু তোমার ফোনে)"; inputType= android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD; setText(decryptKey() ?: "") }
        AlertDialog.Builder(this).setTitle("OpenAI API Key").setMessage("Key শুধু নিজের ফোনে দাও। কাউকে পাঠিও না। APK-তে Key রাখা সম্পূর্ণ নিরাপদ নয়; ব্যক্তিগত পরীক্ষার জন্যই এই সরাসরি সংযোগ।").setView(field).setPositiveButton("নিরাপদে সংরক্ষণ") { _,_-> try { encryptKey(field.text.toString().trim()); Toast.makeText(this,"Key সংরক্ষিত",Toast.LENGTH_SHORT).show() } catch(e:Exception){ Toast.makeText(this,"Key সংরক্ষণ হয়নি: ${e.message}",Toast.LENGTH_LONG).show() } }.setNegativeButton("পরে",null).show()
    }
    private fun getSecretKey():SecretKey {
        val ks=java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing=ks.getKey(keyAlias,null) as? SecretKey; if(existing!=null) return existing
        val kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore")
        kg.init(KeyGenParameterSpec.Builder(keyAlias,KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        return kg.generateKey()
    }
    private fun encryptKey(value:String) { if(value.isBlank()) return; val c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,getSecretKey()); val enc=c.doFinal(value.toByteArray()); prefs.edit().putString("key_iv",Base64.encodeToString(c.iv,Base64.NO_WRAP)).putString("key_data",Base64.encodeToString(enc,Base64.NO_WRAP)).apply() }
    private fun decryptKey():String? { return try { val iv=prefs.getString("key_iv",null)?:return null; val data=prefs.getString("key_data",null)?:return null; val c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.DECRYPT_MODE,getSecretKey(),GCMParameterSpec(128,Base64.decode(iv,Base64.NO_WRAP))); String(c.doFinal(Base64.decode(data,Base64.NO_WRAP))) } catch(_:Exception){ null } }
    private fun saveHistory(){ prefs.edit().putString("history",history.toString()).apply() }
    private fun loadHistory(){ try { val old=JSONArray(prefs.getString("history","[]")); for(i in 0 until old.length()){ val item=old.getJSONObject(i); history.put(item); addBubble(if(item.optString("role")=="user") "তুমি" else "পিউ",item.optString("content")) } } catch(_:Exception){} }
    private fun historyClear(){ historyClearInternal(); transcript.removeAllViews(); addBubble("পিউ","চ্যাটের স্মৃতি মুছে দিয়েছি। আবার নতুন করে কথা বলি।") }
    private fun historyClearInternal(){ while(history.length()>0) { /* rebuilt below because JSONArray has no remove range on old API */; break }; prefs.edit().remove("history").apply(); while(history.length()>0) history.remove(0) }
    override fun onDestroy(){ try { unregisterReceiver(phraseReceiver) } catch (_:Exception) {}; if(::tts.isInitialized) { tts.stop(); tts.shutdown() }; worker.shutdownNow(); super.onDestroy() }
}


/** Simple vector avatar with mouth movement while Android TTS is speaking. */
private class PiuAvatarView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var speaking = false
    private var mouthPhase = 0
    private val density = resources.displayMetrics.density

    fun setSpeaking(value:Boolean) {
        speaking = value
        if(value) animateMouth() else { mouthPhase = 0; invalidate() }
    }

    private fun animateMouth() {
        if(!speaking) return
        mouthPhase = (mouthPhase + 1) % 4
        invalidate()
        postDelayed({ animateMouth() }, 115)
    }

    override fun onDraw(canvas:Canvas) {
        super.onDraw(canvas)
        val w=width.toFloat(); val h=height.toFloat()
        val cx=w/2f; val cy=h/2f
        // soft pink backdrop
        paint.color=Color.rgb(255,225,239); canvas.drawRoundRect(RectF(4f,4f,w-4f,h-4f),28f*density,28f*density,paint)
        // hair behind face
        paint.color=Color.rgb(65,38,48); canvas.drawOval(RectF(cx-76*density,cy-87*density,cx+76*density,cy+83*density),paint)
        // face
        paint.color=Color.rgb(255,220,196); canvas.drawOval(RectF(cx-62*density,cy-72*density,cx+62*density,cy+78*density),paint)
        // hair fringe
        paint.color=Color.rgb(65,38,48); canvas.drawArc(RectF(cx-64*density,cy-78*density,cx+64*density,cy+25*density),180f,180f,true,paint)
        // eyes
        paint.color=Color.rgb(55,35,42)
        canvas.drawCircle(cx-23*density,cy-10*density,4.2f*density,paint)
        canvas.drawCircle(cx+23*density,cy-10*density,4.2f*density,paint)
        // cheeks
        paint.color=Color.rgb(245,145,157)
        canvas.drawCircle(cx-39*density,cy+17*density,8*density,paint)
        canvas.drawCircle(cx+39*density,cy+17*density,8*density,paint)
        // animated mouth: opens/closes while TTS audio plays (visual approximation)
        paint.color=Color.rgb(145,48,75)
        val mouthH=if(speaking && mouthPhase%2==0) 13f else 3.5f
        canvas.drawOval(RectF(cx-10*density,cy+30*density-mouthH/2,cx+10*density,cy+30*density+mouthH/2),paint)
        paint.color=Color.rgb(142,49,95)
        paint.textSize=14f*density; paint.textAlign=Paint.Align.CENTER
        canvas.drawText(if(speaking) "পিউ কথা বলছে…" else "পিউ এখানে আছে 💗",cx,h-14*density,paint)
    }
}
